ZIP ini hanya berisi source code saja karena file terlalu besar untuk diupload di IDE,
adapun file yang belum disertakan adalah folder assets yang berisi gambar, music, dll serta folder uploads,
untuk lebih lengkapnya dapat dilihat pada link git berikut : https://github.com/marcelinoputra/Tubes